package com.example.admin.dto;

public class UserRequest {
}

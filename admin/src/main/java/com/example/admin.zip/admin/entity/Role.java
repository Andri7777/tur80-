package com.example.admin.entity;

public enum Role {

    ADMIN,REDAKTOR;

}
